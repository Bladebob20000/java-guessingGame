import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();
        int randomNumber = random.nextInt(100);
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter the amount of tries");
        int attempts = scanner.nextInt();
        System.out.println("You have " + attempts + " attempts left");

        int userGuess;
        System.out.println("hi");
        System.out.println("guess");
        while (attempts > 0) {
            System.out.println("Enter your guess: ");
            userGuess = scanner.nextInt();
            attempts--;
            System.out.println("You have " + attempts + " attempts left");
            if (userGuess == randomNumber) {
                System.out.println("ggs");
                break;
            } else if (userGuess < randomNumber) {
                System.out.println("too low");
            } else {
                System.out.println("too high");
            }
        }
        System.out.println("the number was " + randomNumber);
        System.out.println("game over");
    }
}