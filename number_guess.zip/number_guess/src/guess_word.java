public class guess_word {
}
